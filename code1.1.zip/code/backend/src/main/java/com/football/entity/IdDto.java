package com.football.entity;

import lombok.Data;

import java.util.List;

@Data
public class IdDto
{

    private List<Integer> idList;

    private List<String> dimensionList;

}
